.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Polly: Collection of CMake toolchains
=====================================

.. warning::

  Documentation is in process of migrating from
  `GitHub wiki <https://github.com/ruslo/polly/wiki>`_.
  Some information may be missing: blank pages, broken links, etc.
  Will be fixed soon...

.. toctree::
   :maxdepth: 1

   /toolchains
