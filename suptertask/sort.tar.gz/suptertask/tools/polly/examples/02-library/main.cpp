#include <iostream>

int foo();

int main() {
  std::cout << "Foo say:" << std::endl;
  foo();
}
