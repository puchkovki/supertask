Please send a patch as a pull request against the branch master.

Also try to follow general notes from here:
* https://github.com/ruslo/hunter/wiki/dev.contribution

Add new toolchain to toolchain table:
* https://github.com/ruslo/polly/blob/master/bin/detail/toolchain_table.py
