#ifndef OSTREAM_
#define OSTREAM_

#include <iostream>

#endif

#ifndef VECTOR_
#define VECTOR_

#include <vector>

#endif

std::vector< int> sort(int a, int b);